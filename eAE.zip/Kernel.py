__author__ = 'Axel Oehmichen'

__all__ = ['Kernel']

class Kernel(object):
    def __init__(self, kernel, C=1.0, degree=3, gamma=0.0, coef0=0.0):
        self.kernel = str(kernel)
        self.degree = int(degree)
        self.gamma = float(gamma)
        self.C = float(C)
        self.coef0 = float(coef0)
        self.verbose = False

    def __reduce__(self):
        return (Kernel, (self.kernel, self.C, self.degree, self.gamma, self.coef0))

    def __str__(self):
        return "The kernel is : %s and the parameters are: ...." + str(self.kernel)
