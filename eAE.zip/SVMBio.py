from pyspark.mllib.classification import SVMWithSGD


class SVMBio(object):


    @classmethod
    def train(cls, TrainingSet, rank=10, iterations=5, lambda_=0.01, blocks=-1, nonnegative=False, seed=None):
        model = SVMWithSGD.train(TrainingSet, rank, iterations, lambda_, blocks, nonnegative, seed)
        return model


