from collections import namedtuple

from pyspark.rdd import RDD
from pyspark.mllib.common import callMLlibFunc, JavaModelWrapper
from pyspark.mllib.util import JavaLoader, JavaSaveable

__all__ = ['MatrixFactorizationModel', 'ALSBio', 'Rating']


class Rating(namedtuple("Rating", ["user", "product", "rating"])):

    def __reduce__(self):
        return Rating, (int(self.user), int(self.product), float(self.rating))


class MatrixFactorizationModel(JavaModelWrapper, JavaSaveable, JavaLoader):

    def predict(self, user, product):
        return self._java_model.predict(int(user), int(product))

    def predictAll(self, user_product):
        assert isinstance(user_product, RDD), "user_product should be RDD of (user, product)"
        first = user_product.first()
        assert len(first) == 2, "user_product should be RDD of (user, product)"
        user_product = user_product.map(lambda (u, p): (int(u), int(p)))
        return self.call("predict", user_product)

    def userFeatures(self):
        return self.call("getUserFeatures")

    def productFeatures(self):
        return self.call("getProductFeatures")

    @classmethod
    def load(cls, sc, path):
        model = cls._load_java(sc, path)
        wrapper = sc._jvm.MatrixFactorizationModelWrapper(model)
        return MatrixFactorizationModel(wrapper)


class ALSBio(object):

    @classmethod
    def _prepare(cls, trainingset):
        assert isinstance(trainingset, RDD), "ratings should be RDD"
        first = trainingset.first()
        if not isinstance(first, Rating):
            if isinstance(first, (tuple, list)):
                trainingset = trainingset.map(lambda x: Rating(*x))
            else:
                raise ValueError("rating should be RDD of Rating or tuple/list")
        return trainingset

    @classmethod
    def train(cls, trainingset, rank, iterations=5, lambda_=0.01, blocks=-1, nonnegative=False, seed=None):
        model = callMLlibFunc("trainALSModel", cls._prepare(trainingset), rank, iterations,
                              lambda_, blocks, nonnegative, seed)
        return MatrixFactorizationModel(model)

    @classmethod
    def trainImplicit(cls, trainingset, rank, iterations=5, lambda_=0.01, blocks=-1, alpha=0.01,
                      nonnegative=False, seed=None):
        model = callMLlibFunc("trainImplicitALSModel", cls._prepare(trainingset), rank,
                              iterations, lambda_, blocks, alpha, nonnegative, seed)
        return MatrixFactorizationModel(model)
